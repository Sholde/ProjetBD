/* rajouter un commentaire a la note d'un film */
alter table Note
add commentaire varchar(256);
