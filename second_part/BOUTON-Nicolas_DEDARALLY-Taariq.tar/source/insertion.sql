/* Requête d'insertion */

/* Clients */
insert into Clients values (1, "Marley", "Bob", "bob.marley@email.com", "bob", 0);
insert into Clients values (2, "Queen", "Alice", "alice.queen@email.com", "alice", 1);
insert into Clients values (3, "Dubreuil", "Clément", "clement.dubreuil@email.com", "clement", 0);
insert into Clients values (4, "Abral", "Mohamed", "mohamed.abral@email.com", "mohamed", 1);
insert into Clients values (5, "Dupont", "Clément", "clement.dupont@email.com", "clement", 0);
insert into Clients values (6, "Zuckerberg", "Mark", "mark.zuckerberg@email.com", "mark", 1);
insert into Clients values (7, "Dupond", "Charles", "charles.dupond@email.com", "charles", 0);
insert into Clients values (8, "Daf", "Max", "max.daf@email.com", "max", 0);
insert into Clients values (9, "Lemond", "Max", "max.lemond@email.com", "max", 0);
insert into Clients values (10, "Valgrin", "Brad", "brad.valgrin@email.com", "brad", 0);
insert into Clients values (11, "Gates", "Bill", "bill.gates@email.com", "bill", 0);
insert into Clients values (12, "Linus", "Torvalds", "linus.torvalds@email.com", "linus", 0);
insert into Clients values (13, "Jobs", "Steve", "steve.jobs@email.com", "steve", 0);
insert into Clients values (14, "Alpher", "Ralph", "Ralph_Asher.Alpher@email.com", "Alpha", 0);
insert into Clients values (15, "Bethe", "Hans", "bethe.1547@email.com", "Beta", 0);
insert into Clients values (16, "Gamow", "George", "brad.valgrin@email.com", "Gamma", 1);
insert into Clients values (17, "Dicaprio", "Leonardo", "leo.caprio@email.com", "leonard", 0);
insert into Clients values (18, "Lemaître", "Georges", "georgelemaitre@email.com", "lemaitre", 0);
insert into Clients values (19, "Dieu", "dieu", "leternel@email.com", "dieu", 1);
insert into Clients values (20, "Van Damme", "jean-claude", "jean-claude@email.com", "vandamme", 1);
insert into Clients values (21, "Curie", "Marie", "marie8764@email.com", "curie", 1);
insert into Clients values (22, "Tournachon", "Gaspard-Félix", "Nadar@email.com", "nad", 0);
insert into Clients values (23, "Dumas", "Alexandre", "dumas_3mousqt@email.com", "alex", 0);
insert into Clients values (24, "Einstein", "Albert", "Einsteinlebg@email.com", "albert", 1);
insert into Clients values (25, "Clayton", "Harold", "Clay744@email.com", "clay", 0);
insert into Clients values (26, "Lawrence", "Ernest", "lawrence.ernest@email.com", "ernest", 0);
insert into Clients values (27, "Murphree", "Eger", "Eger.murphree@email.com", "murph", 0);
insert into Clients values (28, "Compton", "Arthur", "arture.compton@email.com", "art", 0);
insert into Clients values (29, "Bergerac", "Cyrano", "bergerac.cyr@email.com", "cyr", 1);
insert into Clients values (30, "Poquelin", "Jean-Baptiste", "moliere@email.com", "mol", 0);
insert into Clients values (31, "Kant", "Emmanuel", "Kant.Emma@email.com", "manu", 0);
insert into Clients values (32, "Sand", "George", "gege.sand@email.com", "sand", 0);
insert into Clients values (33, "Al-Kachi", "Ghiyath", "kachi@email.com", "kashi", 1);
insert into Clients values (34, "Jackson", "Michaël", "thriller@email.com", "mik", 0);
insert into Clients values (35, "Mendeleïev", "Dmitri", "tableau_periodique@email.com", "dmidmi", 0);
insert into Clients values (36, "Arendt", "Hannah", "Hanna984@email.com", "arendt", 0);
insert into Clients values (37, "Gandhi", "Mohandas Karamchand", "gandhi77816@email.com", "gandhi", 0);
insert into Clients values (38, "Sempé", "Jean-Jacques", "SempeJeanJacques@email.com", "semp", 0);
insert into Clients values (39, "Goscinny", "René", "reneGos@email.com", "gos", 0);
insert into Clients values (40, "Perusse", "Francois", "deuxminpeuple@email.com", "brad", 1);
insert into Clients values (41, "Ravel", "Maurice", "maumau@email.com", "ravel", 0);
insert into Clients values (42, "Remi", "George", "tintindu45@email.com", "tintin", 0);
insert into Clients values (43, "Spinoza", "Baruch", "baruch@email.com", "spin", 0);
insert into Clients values (44, "Franklin", "Benjamin", "benjidu74@email.com", "ben", 0);
insert into Clients values (45, "Goya", "Francisco", "francis.goya@email.com", "goya", 1);
insert into Clients values (46, "Hardy", "Olivier", "hardy.olvier@email.com", "olive", 0);
insert into Clients values (47, "Ionesco", "Eugène", "iones.eug@email.com", "eug", 0);
insert into Clients values (48, "Ali", "Mohamed", "momoleboxeur@email.com", "box", 0);
insert into Clients values (49, "Lavoisier", "Antoine Laurent", "antoinelavoisier@email.com", "ant", 0);
insert into Clients values (50, "Mandela", "Nelson", "mand.nels@email.com", "nels", 0);
insert into Clients values (51, "Kepler","Johannes","Johannes.Kepl@email.com","kel",0);
insert into Clients values (52, "Descartes","René","Descartes.Rene@email.com","ren",1);
insert into Clients values (53, "Torricelli","Evangelista","evang.torr@email.com","eve",0); 
insert into Clients values (54, "Newton","Isaac","iss.newt@email.com","new",0); 
insert into Clients values (55, "Watt","James","watt.james@email.com","watt",0);
insert into Clients values (56, "Becquerel","Henri","henri.beck@email.com","becq",1);
insert into Clients values (57, "Lorentz","Hendrik","lorentz.hendrik@email.com","lo",1);
insert into Clients values (58, "Curie","Pierre","Pierre.curie@email.com","cur",0);
insert into Clients values (59, "Bourgeois","Léon","bourg.leon@email.com","leon",0);                 
insert into Clients values (60, "Simon","Claude","simon.claude@email.com","claude",1);                       
insert into Clients values (61, "Allais","Maurice","allais.maurice@email.com","ail",1);                                               
insert into Clients values (62, "Debreu","Gérard","debreu.gérard@email.com","gege",0);                       
insert into Clients values (63, "Cassin","René","cassin.rene@email.com","rene",0);                       
insert into Clients values (64, "Néel","Louis","louis.neel@email.com","louis",0);                       
insert into Clients values (65, "Jacob","François","jacob.franc@email.com","franc",0);                       
insert into Clients values (66, "Lwoff","André","andre.lwoff@email.com","lw",0);                       
insert into Clients values (67, "Sartre","Jean-Paul","jean.sartre@email.com","jp",0);
insert into Clients values (68, "Camus","Albert","albert.camus@email.com","al",1);
insert into Clients values (69, "Mauriac","François","mauriac.francois@email.com","fanc",0);
insert into Clients values (70, "Jouhaux","Léon","leon.jouhaux@email.com","leon",0);
insert into Clients values (71, "Sauvage","Jean-Pierre","sauvage.jp@email.com","jp",1);
insert into Clients values (72, "Tirole","Jean","jean.tirole@emaiil.com","tirol",0);
insert into Clients values (73, "Modiano","Patrick","modiano.patrick@email.com","modiano",0);
insert into Clients values (74, "Serge","Haroche","serge.haroche@email.com","serg",0);
insert into Clients values (75, "Chauvin","Yves","yves.chauvin@email.com","yves",1);
insert into Clients values (76, "Xingjian","Gao","xingjian.gao@email.com","gao",0);
insert into Clients values (77, "Agre","Peter","peter.agre@email.com","agre",0);
insert into Clients values (78, "Alder","Kurt","alder.kurt@email.com","kurt",1);
insert into Clients values (79, "Altman","Sidney","atlman.sydney@email.com","sid",0);
insert into Clients values (80, "Sanger","Aziz","aziz.sanger@email.com","aziz",0);
insert into Clients values (81, "Shirakawa","Hideki","hideki.shira@email.com","hid",0);
insert into Clients values (82, "Steitz","Thomas","steitz.thomas@email.com","thomas",0);
insert into Clients values (83, "Yonath","Ada","ada.yonath@email.com","yonath",0);
insert into Clients values (84, "Yoshino","Akira","akira.yoshino@email.com","akira",1);
insert into Clients values (85, "Wittig","Georg","wittig.georg@email.com","georg",0);
insert into Clients values (86, "Wallach","Otto","wallach.otto@email.com","otto",0);
insert into Clients values (87, "Warshel","Arieh","warshel.arieh@email.com","ariech",0);
insert into Clients values (88, "Tsien","Roger","tsien.roger@email.com","roger",0);
insert into Clients values (89, "Taube","Henry","henry.taube@email.com","taube",0);
insert into Clients values (90, "Svedberg","Theodor","theodor.svedberg@email.com","theo",0);
insert into Clients values (91, "Smalley","Richard","smalley.richard@email.com","smalley",0);
insert into Clients values (92, "Polanyi","John","polanyi.john@email.com","john",0);
insert into Clients values (93, "Porter","George","george.porter@email.com","porter",1);
insert into Clients values (94, "Pauling","Linus","linus.pauling@email.com","lius",0);
insert into Clients values (95, "Olah","George","george.olah@email.com","olah",0); 
insert into Clients values (96, "Nernst","Walter","nersnt.walter@email.com","ners",0);
insert into Clients values (97, "Natta","Giulio","natta.giulio@email.com","natta",0);
insert into Clients values (98, "Mullis","Kary","kary.mullis@email.com","mullis",0);
insert into Clients values (99, "Mitchell","Peter","peter.mitchell@email.com","peter",0);
insert into Clients values (100, "McMillian","Edwin","ed.mcmillian@email.com","ed",0);
insert into Clients values (101, "Michel","Hartmut","mich.hart@email.com","mich",0);
insert into Clients values (102, "Karle","Jerome","jerome.karle@email.com","karle",0);
insert into Clients values (103, "Karlplus","Martin","karl.plus@email.com","k+",0);
insert into Clients values (104, "Karrer","Paul","karrer.paul@email.com","paul",0);
insert into Clients values (105, "Kendrew","John","john.kendrew@email.com","ken",0);
insert into Clients values (106, "Klug","Aaron","klug.aaron@email.com","klug",0);
insert into Clients values (107, "Kobilka","Brian","kob.brian@email.com","kob",0);
insert into Clients values (108, "Kohn","Walter","kohn.walter@email.com","kohn",0);
insert into Clients values (109, "Kornberg","Roger","kornberg.roger@email.com","roger",0);
insert into Clients values (110, "Kroto","Harold","kroto.harold@email.com","kroto",0);
insert into Clients values (111, "Kuhn","Richard","richard.kuhn@email.com","kuh",0);                       
insert into Clients values (112, "Haber","Fritz","fritz.haber@email.com","fr",0);
insert into Clients values (113, "Hahn","Otto","otto.hahn@email.com","otto",1);
insert into Clients values (114, "Harden","Odd","harden.odd@email.com","odd",0);
insert into Clients values (115, "Boltzmann","Ludwig","boltzman.ludwig@email.com","wig",1);
insert into Clients values (116, "Brunhes","Bernard","bernard.brunches@email.com","nard",1);
insert into Clients values (117, "Diu","Bernard","bernard.diu@email.com","diu",0);
insert into Clients values (118, "Graetzel","Michael","michael.graetzel@email.cm","mich",0);
insert into Clients values (119, "Gonczi","Georges","georges.gonczi@email.com","geo",0);
insert into Clients values (120, "Bruhat","Georges","georges.bruhat@email.com","bru",0); 
insert into Clients values (121, "Rocard","Yves","yves.rocard@email.com","yves",0);
insert into Clients values (122, "Stengers","Isabelle","isa.sten@email.com","sten",1);
insert into Clients values (123, "Reif","Frederic","fred.reif@email.com","fred",0);
insert into Clients values (124, "Jancovici","Bernard","nard.jand@email.com","jan",1);  
insert into Clients values (125, "Kubo","Ryogo","kubo.kubo@email.com","kubo",0);
insert into Clients values (126, "Barberousse","Anouk","barbe.rousse@email.com","rousse",0);
insert into Clients values (127, "Brush","Stephen","steph.bruch@email.com","steph",0);
insert into Clients values (128, "Cercignani","Carlo","carlo.cerc@email.com","carlo",0);
insert into Clients values (129, "Ehrenfest","Paul","paul.ehrenfest@email.com","paul",0);
insert into Clients values (130, "Ehrenfest","Tatiana","tatiana.ehren@email.com","tati",0);
insert into Clients values (131, "Harman","Peter","peter.harman@email.com","peter",0);                     
insert into Clients values (132, "Maury","Jean-Pierre","jp.maury@email.com","maury",0);
insert into Clients values (133, "Cork","James","james.cork@email.com","james",0);
insert into Clients values (134, "Fernandez","Bernard","Fernandez.Bernard@email.com","fer",0);
insert into Clients values (135, "Valentin","Luc","luc.valentin@email.com","luc",0);
insert into Clients values (136, "David","Halliday","halliday.david@email.com","haliday",0);
insert into Clients values (137, "Kaplan","Irving","kaplan.irving@email.com","irving",0);          
insert into Clients values (138, "Wesley","Addison","addison.weshley@email.com","weshl",0);
insert into Clients values (139, "Marx","Karl","karl.marx@email.com","karl",0);
insert into Clients values (140, "Engels","Friedrich","engels.fried@email.com","fried",0);
insert into Clients values (141, "Joly","Maurice","joly.maurice@email.com","joly",0);
insert into Clients values (142, "Tucker","Benjamin","Tucker.benjamin@email.com","ben",0);
insert into Clients values (143, "Brentano","Franz","franz.bren@email.com","franz",0);
insert into Clients values (144, "Max","Frisch","max.frisch@email.com","frisch",0);                                              
insert into Clients values (145, "Mach","Ernst","ernst.mach@email.com","ernst",0);
insert into Clients values (146, "James","William","William.james@email.com","james",0);
insert into Clients values (147, "Cohen","Hermann","cohen.hermann@email.com","herm",0);
insert into Clients values (148, "Tarde","Gabriel","gabriel.tarde@email.com","gab",0);
insert into Clients values (149, "Nietzsche","Friedrich","fried.niet@email.com","fried",0);
insert into Clients values (150, "Frege","Gottlob","frege.gottlob@email.com","frege",0);
insert into Clients values (151, "Freud","Sigmund","freud.Sigmund@email.com","freud",0);
insert into Clients values (152, "Hannequin","Arthur","Hanneq.Art@email.com","art",1);
insert into Clients values (153, "Belot","Gustave","belot.gust@email.com","gust",1);
insert into Clients values (154, "Dewet","John","john.dewet@email.com","dewet",0);
insert into Clients values (155, "Bergson","Henri","henri.bergson@email.com","henri",0);
insert into Clients values (156, "Duhem","Pierre","pierre.duhem@email.com","duhem",0);
insert into Clients values (157, "Blondel","Maurice","maurice.blondel@email.com","blond",0);
insert into Clients values (158, "Palante","Georges","georges.palante@email.com","palante",0);
insert into Clients values (159, "Santayana","George","george.santa@email.com","santa",0);
insert into Clients values (160, "Weber","Max","weber.max@email.com","max",0);
insert into Clients values (161, "Chestov","Léon","leon.chestove@email.com","chestov",0);
insert into Clients values (162, "Croce","Benedetto","croce.benedetto@email.com","croce",0);
insert into Clients values (163, "Max","Scheler","max.scheler@email.com","max",0);
insert into Clients values (164, "Maritain","Jacques","maritain.jacques@email.com","jak",0);
insert into Clients values (165, "Heidegger","Martin","martin.h@email.com","password",0);                      
insert into Clients values (166, "Dalbiez","Roland","roland.dal@email.com","roland",1);
insert into Clients values (167, "Carnap","Rudolf","rudol.carnap@email.com","carnap",0);
insert into Clients values (168, "Hazlitt","Henry","henry.haz@email.com","haz",0);
insert into Clients values (169, "Marcuse","Herbert","marcuse.herbert@email.com","marc",0);
insert into Clients values (170, "Strauss","Leo","leo.strauss@email.com","leo",0);                       


/* Cinema */
insert into Cinema values ("Pathé Boulogne", "Pathé Gaumont");
insert into Cinema values ("Ciné-Sel", "Sel");

/* Salle */
insert into Salle values (1, "Pathé Boulogne", 30, "Boulogne");
insert into Salle values (2, "Pathé Boulogne", 30, "Boulogne");
insert into Salle values (1, "Ciné-Sel", 30, "Sèvres");

/* Film */
insert into Film values (1, "The Matrix", "Science-Fiction - Action", 120, "USA", "all");
insert into Film values (2, "The Matrix reloaded", "Science-Fiction - Action", 120, "USA", "all");
insert into Film values (3, "The Matrix revolution", "Science-Fiction - Action", 120, "USA", "all");
insert into Film values (4, "The social network", "Biographie - Drame", 120, "USA", "all");
insert into Film values (5, "V for Vendetta", "Action", 120, "USA", "vf");
insert into Film values (6, "Die hard", "Action", 120, "USA", "vo");
insert into Film values (7, "Die hard 2", "Action", 120, "USA", "vo");
insert into Film values (8, "Die hard 3", "Action", 120, "USA", "vo");
insert into Film values (9, "Die hard 4", "Action", 120, "USA", "vo");

/* Personne */
/* Matrix (vérifié age) */
insert into Personne values (1, "Reeves", "Keanu", 55);
insert into Personne values (2, "Fishburne", "Laurence", 58);
insert into Personne values (3, "Wachowski", "Lilly", 62);
insert into Personne values (4, "Wachowski", "Lana", 60);
insert into Personne values (5, "Moss", "Carrie-Anne", 62);

/* The social Network */
insert into Personne values (6, "Fincher", "David", 57);
insert into Personne values (7, "Sorkin", "Aaron", 58);
insert into Personne values (8, "Eisenberg", "Jesse", 36);
insert into Personne values (9, "Garfield", "Andrew", 36);
insert into Personne values (10, "Timberlake", "Justin", 38);

/* V for Vendetta */
insert into Personne values (11, "McTeigue", "James", 52);
insert into Personne values (12, "Weaving", "Hugo", 59);
insert into Personne values (13, "Portman", "Natalie", 38);
insert into Personne values (14, "Graves", "Rupert", 56);

/* Die hard */
insert into Personne values (15, "McTierman", "John", 68);
insert into Personne values (16, "Willis", "Bruce", 62);
insert into Personne values (17, "Stuart", "James", 63);
insert into Personne values (18, "Rickman", "Alan", 69);

/* Suit */
insert into Suit values (1, 2);
insert into Suit values (2, 3);
insert into Suit values (6, 7);
insert into Suit values (7, 8);
insert into Suit values (8, 9);

/* Participe au film */
insert into Participe_au_film values (1, 1, "Acteur");
insert into Participe_au_film values (2, 1, "Acteur");
insert into Participe_au_film values (3, 1, "Directrice - Scénariste");
insert into Participe_au_film values (4, 1, "Directrice - Scénariste");
insert into Participe_au_film values (5, 1, "Actrice");

insert into Participe_au_film values (1, 2, "Acteur");
insert into Participe_au_film values (2, 2, "Acteur");
insert into Participe_au_film values (3, 2, "Directrice - Scénariste");
insert into Participe_au_film values (4, 2, "Directrice - Scénariste");
insert into Participe_au_film values (5, 2, "Actrice");

insert into Participe_au_film values (1, 3, "Acteur");
insert into Participe_au_film values (2, 3, "Acteur");
insert into Participe_au_film values (3, 3, "Directrice - Scénariste");
insert into Participe_au_film values (4, 3, "Directrice - Scénariste");
insert into Participe_au_film values (5, 3, "Actrice");

insert into Participe_au_film values (6, 4,"Directeur");
insert into Participe_au_film values (7, 4, "Scénariste");
insert into Participe_au_film values (8, 4, "Acteur");
insert into Participe_au_film values (9, 4, "Acteur");
insert into Participe_au_film values (10, 4, "Acteur");

insert into Participe_au_film values (3, 5, "Scénariste");
insert into Participe_au_film values (4, 5, "Scénariste");
insert into Participe_au_film values (11, 5, "Directeur");
insert into Participe_au_film values (12, 5, "Acteur");
insert into Participe_au_film values (13, 5, "Actrice");
insert into Participe_au_film values (14, 5, "Acteur");

insert into Participe_au_film values (15, 6, "Directeur");
insert into Participe_au_film values (16, 6, "Acteur");
insert into Participe_au_film values (17, 6, "Scénariste");
insert into Participe_au_film values (18, 6, "Acteur");

insert into Participe_au_film values (15, 7, "Directeur");
insert into Participe_au_film values (16, 7, "Acteur");
insert into Participe_au_film values (17, 7, "Scénariste");

insert into Participe_au_film values (15, 8, "Directeur");
insert into Participe_au_film values (16, 8, "Acteur");
insert into Participe_au_film values (17, 8, "Scénariste");

insert into Participe_au_film values (15, 9, "Directeur");
insert into Participe_au_film values (16, 9, "Acteur");
insert into Participe_au_film values (17, 9, "Scénariste");

/* Se_joue_dans */ /* On va mettre les films la semaine du 16 vu qu on va présenté cette semaine la */
insert into Se_joue_dans values(1, '2019-12-16', '10:00:00', "vf", 1, 1, "Pathé Boulogne");
insert into Se_joue_dans values(2, '2019-12-16', '10:00:00', "vo", 6, 2, "Pathé Boulogne");
insert into Se_joue_dans values(3, '2019-12-16', '15:00:00', "vf", 2, 1, "Pathé Boulogne");
insert into Se_joue_dans values(4, '2019-12-16', '16:00:00', "vf", 5, 2, "Pathé Boulogne");

insert into Se_joue_dans values(5, '2019-12-16', '10:00:00', "vf", 4, 1, "Ciné-Sel");
insert into Se_joue_dans values(6, '2019-12-16', '15:00:00', "vf", 5, 1, "Ciné-Sel");

insert into Se_joue_dans values(7, '2019-12-17', '09:00:00', "vf", 3, 1, "Pathé Boulogne");
insert into Se_joue_dans values(8, '2019-12-17', '11:00:00', "vf", 1, 1, "Ciné-Sel");

insert into Se_joue_dans values(9, '2019-12-18', '17:00:00', "vf", 4, 1, "Pathé Boulogne");
insert into Se_joue_dans values(10, '2019-12-18', '17:00:00', "vo", 6, 1, "Ciné-Sel");

insert into Se_joue_dans values(11, '2019-12-20', '14:00:00', "vo", 2, 1, "Ciné-Sel");

insert into Se_joue_dans values(12, '2019-12-21', '21:00:00', "vo", 1, 1, "Pathé Boulogne");


/* Veut_voir */ /* 6 euro sans reduc, 5 euro avec */
insert into Veut_voir values(1, 1, 1, 1, 6);
insert into Veut_voir values(2, 1, 1, 1, 6);
insert into Veut_voir values(3, 1, 2, 1, 5);
insert into Veut_voir values(4, 1, 50, 1, 6);
insert into Veut_voir values(5, 1, 50, 1, 6);
insert into Veut_voir values(6, 1, 50, 1, 6);
insert into Veut_voir values(7, 1, 50, 1, 5);
insert into Veut_voir values(8, 1, 50, 1, 6);
insert into Veut_voir values(9, 1, 45, 1, 6);
insert into Veut_voir values(10, 1, 45, 1, 6);
insert into Veut_voir values(11, 1, 45, 1, 5);
insert into Veut_voir values(12, 1, 45, 1, 6);
insert into Veut_voir values(13, 1, 45, 1, 6);
insert into Veut_voir values(14, 1, 45, 1, 6);
insert into Veut_voir values(15, 1, 45, 1, 5);
insert into Veut_voir values(16, 1, 45, 1, 6);
insert into Veut_voir values(17, 1, 45, 1, 6);
insert into Veut_voir values(18, 1, 30, 1, 5);
insert into Veut_voir values(19, 1, 30, 1, 6);
insert into Veut_voir values(20, 1, 30, 1, 6);
insert into Veut_voir values(21, 1, 30, 1, 6);
insert into Veut_voir values(22, 1, 5, 1, 5);
insert into Veut_voir values(23, 1, 12, 1, 6);

insert into Veut_voir values(24, 2, 6, 6, 6);
insert into Veut_voir values(25, 2, 6, 6, 6);
insert into Veut_voir values(26, 2, 6, 6, 5);
insert into Veut_voir values(27, 2, 24, 6, 6);
insert into Veut_voir values(28, 2, 24, 6, 6);
insert into Veut_voir values(29, 2, 24, 6, 6);
insert into Veut_voir values(30, 2, 24, 6, 5);
insert into Veut_voir values(31, 2, 47, 6, 6);
insert into Veut_voir values(32, 2, 47, 6, 6);

insert into Veut_voir values(33, 3, 109, 2, 5);
insert into Veut_voir values(34, 3, 109, 2, 6);
insert into Veut_voir values(34, 3, 109, 2, 6);
insert into Veut_voir values(35, 3, 109, 2, 5);
insert into Veut_voir values(36, 3, 64, 2, 6);
insert into Veut_voir values(37, 3, 64, 2, 6);
insert into Veut_voir values(38, 3, 64, 2, 5);
insert into Veut_voir values(39, 3, 64, 2, 6);
insert into Veut_voir values(40, 3, 64, 2, 6);
insert into Veut_voir values(41, 3, 64, 2, 5);
insert into Veut_voir values(42, 3, 134, 2, 6);
insert into Veut_voir values(43, 3, 134, 2, 6);
insert into Veut_voir values(44, 3, 134, 2, 5);
insert into Veut_voir values(45, 3, 134, 2, 6);
insert into Veut_voir values(46, 3, 78, 2, 6);
insert into Veut_voir values(47, 3, 78, 2, 5);
insert into Veut_voir values(48, 3, 78, 2, 6);
insert into Veut_voir values(49, 3, 78, 2, 6);

insert into Veut_voir values(50, 4, 109, 5, 5);
insert into Veut_voir values(51, 4, 117, 5, 6);
insert into Veut_voir values(52, 4, 160, 5, 6);
insert into Veut_voir values(53, 4, 10, 5, 5);
insert into Veut_voir values(54, 4, 57, 5, 6);
insert into Veut_voir values(55, 4, 57, 5, 6);
insert into Veut_voir values(56, 4, 57, 5, 5);
insert into Veut_voir values(57, 4, 57, 5, 6);
insert into Veut_voir values(58, 4, 76, 5, 6);
insert into Veut_voir values(59, 4, 76, 5, 5);
insert into Veut_voir values(60, 4, 131, 5, 6);
insert into Veut_voir values(61, 4, 137, 5, 6);
insert into Veut_voir values(62, 4, 131, 5, 5);
insert into Veut_voir values(63, 4, 8, 5, 6);
insert into Veut_voir values(64, 4, 81, 5, 6);
insert into Veut_voir values(65, 4, 81, 5, 5);
insert into Veut_voir values(66, 4, 81, 5, 6);
insert into Veut_voir values(67, 4, 81, 5, 6);

insert into Veut_voir values(68, 5, 14, 4, 6);
insert into Veut_voir values(70, 5, 14, 4, 5);
insert into Veut_voir values(71, 5, 14, 4, 6);
insert into Veut_voir values(72, 5, 14, 4, 6);

insert into Veut_voir values(73, 6, 11, 5, 6);
insert into Veut_voir values(74, 6, 14, 5, 5);
insert into Veut_voir values(75, 6, 99, 5, 6);
insert into Veut_voir values(76, 6, 99, 5, 6);
insert into Veut_voir values(77, 6, 99, 5, 6);
insert into Veut_voir values(78, 6, 99, 5, 5);
insert into Veut_voir values(79, 6, 126, 5, 6);
insert into Veut_voir values(80, 6, 126, 5, 6);

insert into Veut_voir values(81, 7, 87, 3, 6);
insert into Veut_voir values(82, 7, 87, 3, 6);
insert into Veut_voir values(83, 7, 87, 3, 6);
insert into Veut_voir values(84, 7, 87, 3, 6);

insert into Veut_voir values(85, 8, 104, 1, 6);
insert into Veut_voir values(86, 8, 104, 1, 6);
insert into Veut_voir values(87, 8, 7, 1, 6);
insert into Veut_voir values(88, 8, 8, 1, 6);
insert into Veut_voir values(89, 8, 8, 1, 6);

insert into Veut_voir values(90, 9, 44, 4, 6);
insert into Veut_voir values(91, 9, 44, 4, 6);
insert into Veut_voir values(92, 9, 44, 4, 6);
insert into Veut_voir values(93, 9, 44, 4, 6);
insert into Veut_voir values(94, 9, 44, 4, 6);
insert into Veut_voir values(95, 9, 44, 4, 6);
insert into Veut_voir values(96, 9, 44, 4, 6);
insert into Veut_voir values(97, 9, 44, 4, 6);

insert into Veut_voir values(98, 10, 153, 6, 6);
insert into Veut_voir values(99, 10, 153, 6, 6);
insert into Veut_voir values(100, 10, 153, 6, 6);
insert into Veut_voir values(101, 10, 153, 6, 6);
insert into Veut_voir values(102, 10, 153, 6, 6);
insert into Veut_voir values(103, 10, 153, 6, 6);
insert into Veut_voir values(104, 10, 153, 6, 6);
insert into Veut_voir values(105, 10, 153, 6, 6);
insert into Veut_voir values(106, 10, 153, 6, 6);
insert into Veut_voir values(107, 10, 153, 6, 6);
insert into Veut_voir values(108, 10, 153, 6, 6);
insert into Veut_voir values(109, 10, 153, 6, 6);
insert into Veut_voir values(110, 10, 153, 6, 6);
insert into Veut_voir values(111, 10, 153, 6, 6);
insert into Veut_voir values(112, 10, 153, 6, 6);
insert into Veut_voir values(113, 10, 153, 6, 6);

insert into Veut_voir values(114, 11, 36, 2, 6);
insert into Veut_voir values(115, 11, 36, 2, 6);
insert into Veut_voir values(116, 11, 36, 2, 6);
insert into Veut_voir values(117, 11, 144, 2, 6);
insert into Veut_voir values(118, 11, 36, 2, 6);
insert into Veut_voir values(119, 11, 36, 2, 6);
insert into Veut_voir values(120, 11, 36, 2, 6);
insert into Veut_voir values(121, 11, 36, 2, 6);

insert into Veut_voir values(122, 12, 14, 1, 6);
insert into Veut_voir values(123, 12, 15, 1, 6);
insert into Veut_voir values(124, 12, 14, 1, 6);
insert into Veut_voir values(125, 12, 14, 1, 6);
insert into Veut_voir values(126, 12, 117, 1, 6);
insert into Veut_voir values(127, 12, 117, 1, 6);
insert into Veut_voir values(128, 12, 9, 1, 6);
insert into Veut_voir values(129, 12, 9, 1, 6);

/* Note */
insert into Note values(21,4,4);
insert into Note values(18,5,5);
insert into Note values(10,7,4);
insert into Note values(4,5,1);
insert into Note values(50,1,5);
insert into Note values(41,3,4);
insert into Note values(20,4,3);
insert into Note values(45,4,2);
insert into Note values(21,1,3);
insert into Note values(22,5,4);
insert into Note values(6,3,5);
insert into Note values(12,2,2);
insert into Note values(34,1,3);
insert into Note values(1,1,3);
insert into Note values(99, 4, 5);
insert into Note values(157, 2, 4);
insert into Note values(20, 6, 3);
insert into Note values(32, 5, 1);
insert into Note values(144, 1, 4);
insert into Note values(14, 7, 2);
insert into Note values(112, 3, 3);
insert into Note values(101, 3, 3);
insert into Note values(139, 3, 4);
insert into Note values(4, 8, 1);
insert into Note values(55, 7, 2);
insert into Note values(55, 1, 5);
insert into Note values(133, 8, 1);
insert into Note values(4, 6, 2);
insert into Note values(67, 4, 2);
insert into Note values(37, 9, 2);
insert into Note values(1, 4, 3);
insert into Note values(152, 8, 3);
insert into Note values(152, 1, 3);
insert into Note values(152, 4, 4);
